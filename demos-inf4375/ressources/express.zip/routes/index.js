var express = require('express');
var router = express.Router();
var fs = require("fs");

/* GET home page. */
router.get('/', function(req, res) {
  res.render('index', { title: 'Express' });
});

router.get('/cours/:no', function(req, res) {
  res.setHeader('Content-type', 'application/json');
  var no = req.params.no;
  fs.readFile('views/json/cours'+no+'.json', function(err, data){
  	res.end(data);
  });
});

router.get('/cours', function(req, res) {
  res.setHeader('Content-type', 'application/json');
  fs.readFile("views/json/mescours.json", function(err, data){
  	res.end(data);
  });
});

module.exports = router;
